<?php
require 'funksjoner.php'; 
?>
<!DOCTYPE html>
<html lang="no">

<head>
  <meta charset="utf-8">
  <meta name="author" content="bitjungle">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO"
    crossorigin="anonymous">
  <link rel="stylesheet" href="stiler/mcbergbys-bootstrap.css" />
  <title>McBergbys bestillingssystem</title>
</head>

<body>
  <nav class="navbar nav-tabs fixed-top bg-dark navbar-dark navbar-expand-sm pb-0">
    <div class="container">
      <a class="navbar-brand" id="logo" href="#">
        <img src="bilder/burger-1487481.svg" alt="McBergbys logo - CC0 midicomp" style="width: 40px;">McBergbys</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#hamburgermeny" aria-controls="hamburgermeny"
        aria-expanded="false" aria-label="Vis navigasjonsmeny">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="hamburgermeny">
        <div class="navbar-nav ml-auto">
          <a class="nav-item nav-link active" href="index.php">Bestilling</a>
          <a class="nav-item nav-link" href="om.php">Om&nbsp;McBergbys</a>
          <a class="nav-item nav-link" href="hamburgerskolen.php">Burgerskolen</a>
        </div><!-- navbar-bar -->
      </div><!-- navbar-collapse -->
      <span class="navbar-text d-none d-xl-inline-block ml-5 bg-dark text-white" id="slogan">Vi har de feteste
        burgerne!</span>
    </div><!-- container -->
  </nav>
  <div class="container" id="hovedomraade">

    <h1>Bestill fra McBergbys</h1>

    <h2>Sett sammen din meny</h2>
    <p>En meny koster kr. 99,- uansett hvilken kombinasjon du velger.</p>

    <form action="bestillingsmottak.php" method="post">

      <input type="hidden" id="totalpris" name="totalpris" value="99" />

      <div class="container" id="burgerbilde">
        <img class="img-fluid rounded float-md-right mx-sm-5" src="bilder/hamburgers-400.jpg" alt="Hamburgere - Unsplash License Niklas Rhöse" />
      </div><!-- burgerbilde -->

      <fieldset class="form-group" id="personinfo">
        <h4>Din kontaktinfo:</h4>
        <div class="form-group">
          <label class="form-control-label" for="fornavn">Foravn</label>
          <input class="form-control mr-5" type="text" name="fornavn" id="validationDefault01" placeholder="Fornavn" required />
          <label class="form-control-label" for="etternavn">Etternavn</label>
          <input class="form-control mr-5" type="text" name="etternavn" id="validationDefault02" placeholder="Etternavn" required />
        </div><!-- form-group -->
        <div class="form-group">
          <label class="form-control-label" for="tlf">Mobilnr.</label>
          <input class="form-control" type="text" name="tlf" id="validationDefault03" placeholder="### ## ###" />
        </div><!-- form-group -->
      </fieldset><!-- personinfo -->

      <fieldset class="form-group" id="burgervelger">
        <h4>Burger:</h4>
        <div class="form-check">
          <input type="radio" name="burger" id="superburger" value="superburger" class="form-check-input" />
          <label for="superburger" class="form-check-label">Superburger - alles favoritt</label>
          <span class="badge badge-success badge-pill">Bestselger</span>
        </div><!-- form-check -->
        <div class="form-check">
          <input type="radio" name="burger" id="cheeseburger" value="cheeseburger" class="form-check-input" />
          <label for="cheeseburger" class="form-check-label">Cheeseburger - hvis du liker ost</label>
        </div><!-- form-check -->
        <div class="form-check">
          <input type="radio" name="burger" id="veggisburger" value="veggisburger" class="form-check-input" />
          <label for="veggisburger" class="form-check-label">Veggis - for deg som er glad i planter</label>
        </div><!-- form-check -->
      </fieldset><!-- burgervelger -->

      <div class="container" id="drikkebilde">
        <img class="img-fluid rounded float-md-right mx-sm-5" src="bilder/drinks-400.jpg" alt="Drikkevarer - CC0 rawpixel (pixabay)" />
      </div><!-- drikkebilde -->

      <fieldset class="form-group" id="drikkevelger">
        <h4>Drikke:</h4>
        <div class="form-check">
          <input type="radio" name="drikke" id="cola" value="cola" class="form-check-input" />
          <label for="cola" class="form-check-label">Cola</label>
        </div><!-- form-check -->
        <div class="form-check">
          <input type="radio" name="drikke" id="solo" value="solo" class="form-check-input" />
          <label for="solo" class="form-check-label">Solo</label>
        </div><!-- form-check -->
        <div class="form-check">
          <input type="radio" name="drikke" id="sitronbrus" value="sitronbrus" class="form-check-input" />
          <label for="sitronbrus" class="form-check-label">Sitronbrus</label>
        </div><!-- form-check -->
        <div class="form-check">
          <input type="radio" name="drikke" id="vann" value="vann" class="form-check-input" />
          <label for="vann" class="form-check-label">Vann</label>
          <span class="badge badge-info badge-pill">Sunt valg</span>
        </div><!-- form-check -->
      </fieldset><!-- drikkevelger -->

      <fieldset class="form-group" id="tilbehør">
        <h4>Tilbehør:</h4>
        <div class="form-check">
          <input type="radio" name="tilbehør" id="pommesfrites" value="pommesfrites" class="form-check-input" />
          <label for="pommesfrites" class="form-check-label">Pommes frites</label>
        </div><!-- form-check -->
        <div class="form-check">
          <input type="radio" name="tilbehør" id="løkringer" value="løkringer" class="form-check-input" />
          <label for="løkringer" class="form-check-label">Løkringer</label>
          <span class="badge badge-danger badge-pill">Nyhet</span>
        </div><!-- form-check -->
        <div class="form-check">
          <input type="radio" name="tilbehør" id="cheesesticks" value="cheesesticks" class="form-check-input" />
          <label for="cheesesticks" class="form-check-label">Cheese sticks</label>
        </div><!-- form-check -->
      </fieldset><!-- tilbehør -->

      <fieldset class="form-group" id="ekstra">
        <h4>Annet:</h4>
        <div class="form-check">
          <input type="checkbox" name="ekstra[]" id="ketchup" value="ketchup" class="form-check-input" />
          <label for="ketchup" class="form-check-label">Ketchup laget av ekte tomater</label>
        </div><!-- form-check -->
        <div class="form-check">
          <input type="checkbox" name="ekstra[]" id="sennep" value="sennep" class="form-check-input" />
          <label for="sennep" class="form-check-label">Sennep av den knallsterke typen</label>
          <span class="badge badge-warning badge-pill">Sterk</span>
        </div><!-- form-check -->
        <div class="form-check">
          <input type="checkbox" name="ekstra[]" id="grillkrydder" value="grillkrydder" class="form-check-input" />
          <label for="grillkrydder" class="form-check-label">Grillkrydder som passer til alt</label>
        </div><!-- form-check -->
        <div class="form-check">
          <input type="checkbox" name="ekstra[]" id="dip" value="dip" class="form-check-input" />
          <label for="dip" class="form-check-label">Dip laget etter vår hemmelige oppskrift</label>
        </div><!-- form-check -->
      </fieldset><!-- ekstra -->

      <fieldset class="form-group" id="skjemaknapper">
        <label for="send">Klar for å plassere ordren?</label><br />
        <input type="submit" value="Send bestilling" class="btn btn-primary" id="send" />
        <input type="reset" value="Nullstill skjema" class="btn btn-warning" />
      </fieldset><!-- skjemaknapper -->
    </form>

  </div><!-- hovedomraade -->
  
<?php
  lag_footer();
?>
</body>

</html>